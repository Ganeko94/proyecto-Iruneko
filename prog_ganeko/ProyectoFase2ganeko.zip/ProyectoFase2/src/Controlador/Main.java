package Controlador;

import Vista.*;
import Modelo.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

public class Main {

    private static VentanaCentro vc;
    private static VentanaPerfil vp; 
    private static DialogCentro dc;
    
    private static Trabajador t;
    private static Centro c;    
    
    //private static Calendar cal = Calendar.getInstance();
    
    //private static ArrayList<String> nombres = new ArrayList();
    
    //*private static ArrayList<Integer> centros = new ArrayList();
    
    //private static DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    
    private static int x;
    private static int y;
    
    public static void main(String[] args) {
        
        t = new Trabajador();
        mostrarCentro();
        
        
    }
    
    public static ArrayList<Integer> datosCentros() throws Exception{
        return CentroBD.buscarCentros();
 
    }
    
    public static String nombreCentro(Integer idCentro) throws Exception{
        c = CentroBD.buscarCentroID(idCentro);
        return c.getNombre();
    }
    

//    public static void rellenarEditar(String user, String pass){
//        for(y=0 ; y < listaPersona.size() && listaPersona.get(y).getUsu().getUser().compareTo(user)!=0 && listaPersona.get(y).getUsu().getPass().compareTo(pass)!=0 ; y++){}
//        p = listaPersona.get(y);
//    }
//    
//    public static boolean comprobarUserLogin(String user){
//        
//        for(x=0 ; x < listaUsuario.size() && listaUsuario.get(x).getUser().compareTo(user)!=0 ; x++){}
//        if(x == listaUsuario.size())
//        {
//            return false;
//        }
//        else
//        {
//            return true;
//        }
//    }
//    
//    public static boolean comprobarPassLogin(String pass){
//        if(listaUsuario.get(x).getPass().compareTo(pass)!=0){
//            return false;
//        }
//        else
//        {
//            return true;
//        }
//        
//    }
    
//    public static void convertirFechaToCalendar(){
//        try{
//            
//        cal.setTime(df.parse(getT().getFechanac()));
//        }
//        catch(Exception e){
//            JOptionPane.showMessageDialog(null, "Error al convertir la fecha");
//        }
//    }
    
    public static void mostrarCentro(){
        vc = new VentanaCentro();
        vc.setVisible(true);
    }
   
    
    public static void mostrarVentanaPerfil(){
        vp = new VentanaPerfil();
        vp.setVisible(true);
    }
    
    public static void mostrarNuevoCentro(){
        dc = new DialogCentro(vc, true);
        dc.setVisible(true);
    }
    
    public static void volverCentro(){
        vp.setVisible(false);
        mostrarCentro();
    }
    
    public static void pasoPerfil(){
        vc.setVisible(false);
        mostrarVentanaPerfil();
    }
    
    public static void obtenerTrabajador(Trabajador tr, Centro c)throws Exception{
        
        t = TrabajadorBD.buscarDni(tr.getDni(), c);
        
    }
    
    public static void obtenerCentro(Centro ce)throws Exception{
        
        c = CentroBD.buscarCentroID(ce.getId_centro());
        
    }
    
    public static void guardarCentro(int id)throws Exception{
        
        c = CentroBD.buscarCentroID(id);
        
    }

    public static Centro getC() {
        return c;
    }

    public static Trabajador getT() {
        return t;
    }
    
    public static Calendar getFecha(){
        Calendar cal =  Calendar.getInstance();
        cal.setTime(t.getFecha_nac());
        return cal;
    }

    
 
}
