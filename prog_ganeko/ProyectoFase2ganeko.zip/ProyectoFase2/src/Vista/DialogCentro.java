/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Excepciones.CampoVacio;
import Modelo.*;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog04
 */
public class DialogCentro extends javax.swing.JDialog {

    private Centro c;
    private String decision;
    /**
     * Creates new form DialogCentro
     */
    public DialogCentro(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        desactivarCampos();
    }

    public void llenarCampos(){
        tfNombre.setText(Controlador.Main.getC().getNombre());
        tfTelefono.setText(Controlador.Main.getC().getTlf_fijo());
        tfCP.setText(Controlador.Main.getC().getCp().toString());
        tfProvincia.setText(Controlador.Main.getC().getProvincia());
        tfCiudad.setText(Controlador.Main.getC().getCiudad());
        tfCalle.setText(Controlador.Main.getC().getCalle());
        tfNumero.setText(Controlador.Main.getC().getNumero());

    }
    
    public void desactivarCampos(){
        tfNombre.setEditable(false);
        tfTelefono.setEditable(false);
        tfCP.setEditable(false);
        tfProvincia.setEditable(false);
        tfCiudad.setEditable(false);
        tfCalle.setEditable(false);
        tfNumero.setEditable(false);
    }
    
    public void activarCampos(){
        tfID.setEditable(true);
        tfNombre.setEditable(true);
        tfTelefono.setEditable(true);
        tfCP.setEditable(true);
        tfProvincia.setEditable(true);
        tfCiudad.setEditable(true);
        tfCalle.setEditable(true);
        tfNumero.setEditable(true);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        bAceptar = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tfID = new javax.swing.JTextField();
        tfNombre = new javax.swing.JTextField();
        tfTelefono = new javax.swing.JTextField();
        tfCP = new javax.swing.JTextField();
        tfProvincia = new javax.swing.JTextField();
        tfCiudad = new javax.swing.JTextField();
        tfCalle = new javax.swing.JTextField();
        tfNumero = new javax.swing.JTextField();
        bComprobar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel1.setText("Nuevo Centro");

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Codigo de Centro:");

        jLabel3.setText("Nombre:");

        jLabel4.setText("Telefono:");

        jLabel5.setText("Codigo Postal:");

        jLabel6.setText("Provincia:");

        jLabel7.setText("Ciudad:");

        jLabel8.setText("Calle:");

        jLabel9.setText("Numero:");

        bComprobar.setText("Comprobar");
        bComprobar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bComprobarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(tfNumero, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tfCP, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(144, 144, 144))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(tfCiudad, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tfProvincia, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tfCalle, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tfNombre, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tfID)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(tfTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE)))
                                        .addGap(34, 34, 34)))
                                .addComponent(bComprobar))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(bAceptar)
                        .addGap(94, 94, 94)
                        .addComponent(bCancelar)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bComprobar))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfCP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tfCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tfCalle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(tfNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 87, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bAceptar)
                            .addComponent(bCancelar))
                        .addGap(41, 41, 41))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bComprobarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bComprobarActionPerformed
        try{
                
                c = CentroBD.buscarCentroID(Integer.parseInt(tfID.getText()));
                if (c == null){
                JOptionPane.showMessageDialog(this, "No hay ningun centro con este ID, introduce los datos del nuevo centro");
                activarCampos();  
                decision = "alta";
                }
                else
                {
                Controlador.Main.obtenerCentro(c);
                llenarCampos();
                tfID.setEnabled(false);
                int seleccion = JOptionPane.showOptionDialog(this, "Se ha encontrado al centro, ¿que acción quieres realizar?", "Selector de opciones", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,  new Object[] { "Cancelar", "Borrar", "Modificar" }, "Cancelar");
                
                if (seleccion == 1){
                    System.out.println("seleccionada opcion " + (seleccion + 1) + " borrar");
                    decision = "borrar";
                }
                else if (seleccion == 2){
                    System.out.println("seleccionada opcion " + (seleccion + 1) + " modificar");
                    decision = "modificar";
                    tfID.setEnabled(true);
                    activarCampos();
                }
            }
        }
   
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error cualquiera" + e.getMessage());
        }
    }//GEN-LAST:event_bComprobarActionPerformed

    private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_bCancelarActionPerformed

    private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
       try{
            
        if(tfNombre.getText() == null || tfNombre.getText() == null || tfTelefono.getText() == null || tfCP.getText() == null || tfProvincia.getText() == null || tfCiudad.getText() == null || tfCalle.getText() == null || tfNumero.getText() == null)    
        {
            throw new CampoVacio();
        }
        if("alta".equals(decision)){
            
        CentroBD.insertar(Integer.parseInt(tfID.getText()),tfNombre.getText(), tfTelefono.getText(), Integer.parseInt(tfCP.getText()), tfProvincia.getText(), tfCiudad.getText(), tfCalle.getText(), tfNumero.getText());
        this.dispose();
        }
        else if("borrar".equals(decision))
        {
            int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar el centro?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el centro " + tfID.getText()); 
            CentroBD.borrar(Integer.parseInt(tfID.getText()));
            this.dispose();
            }
            else if(JOptionPane.OK_CANCEL_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
            }
            
        }
        else if("modificar".equals(decision))
        {
            int r2 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer modificar al centro?");
            
            if (JOptionPane.OK_OPTION == r2){
            JOptionPane.showMessageDialog(this, "Se ha modificado al centro " + tfID.getText()); 
            CentroBD.actualizar(Integer.parseInt(tfID.getText()),tfNombre.getText(), tfTelefono.getText(), Integer.parseInt(tfCP.getText()), tfProvincia.getText(), tfCiudad.getText(), tfCalle.getText(), tfNumero.getText());
            this.dispose();
            }
            else if(JOptionPane.OK_CANCEL_OPTION == r2){
            JOptionPane.showMessageDialog(this, "Vale, no se ha realizado ningun cambio");
            }            
        }
        else
        {
            JOptionPane.showMessageDialog(this, "No hay ninguna acción que hacer con este centro");
        }
        }
        catch(CampoVacio e){
            JOptionPane.showMessageDialog(this, "Hay uno o más campos vacios / " + e.getMessage());
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido un error cualquiera / " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DialogCentro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DialogCentro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DialogCentro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DialogCentro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DialogCentro dialog = new DialogCentro(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bComprobar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField tfCP;
    private javax.swing.JTextField tfCalle;
    private javax.swing.JTextField tfCiudad;
    private javax.swing.JTextField tfID;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfNumero;
    private javax.swing.JTextField tfProvincia;
    private javax.swing.JTextField tfTelefono;
    // End of variables declaration//GEN-END:variables
}
