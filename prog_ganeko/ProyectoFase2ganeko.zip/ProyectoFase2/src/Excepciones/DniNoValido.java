
package Excepciones;

/**
 *
 * @author 1GPROG04
 */
public class DniNoValido extends Exception{
    
}
