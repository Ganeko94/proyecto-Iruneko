package Excepciones;

public class CampoVacio extends Exception{
    
}
