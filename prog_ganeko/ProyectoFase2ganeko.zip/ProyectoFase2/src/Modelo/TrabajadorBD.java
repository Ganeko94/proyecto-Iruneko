package Modelo;

import java.sql.*;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog04
 */


public class TrabajadorBD extends GenericoBD{
    
    private static Trabajador t;
    
    
    public static Trabajador buscarDni(String dni, Centro c) throws Exception{
        
        
            abrirConexion();
            String plantilla="SELECT * FROM Trabajadores WHERE dni = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();
            
            
            if (resultado.next() == false)
            {
                t = null;
            }
            else
            {
                if (resultado.getString("tipo").compareToIgnoreCase("A") == 0)
                {
                    t = new Administracion();
                }
                else
                {
                    t = new TransporteLogistica();
                }
                
                //if (resultado.getInt("idCentro")== c.getId())
                //{

                t.setDni(resultado.getString("dni"));
            
            
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_personal(resultado.getString("tlf_personal"));
                t.setTlf_empresa(resultado.getString("tlf_empresa"));
                t.setFecha_nac(resultado.getDate("fecha_nac"));
                t.setSalario(resultado.getFloat("salario"));
                t.setTipo(resultado.getString("tipo"));
                t.setCentro_id(resultado.getInt("Centros_id_centro"));
                }
                
            cerrarConexion();
            return t;
        
        
    }
    
    public static void borrar(String dni)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Trabajadores WHERE dni = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
             
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }     
        
    
    
    public static void actualizar(String dni, String nom, String ape1, String ape2, String calle, String num, String piso, String mano, String emp, String per,Calendar fech, Float sal, String tipo) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Trabajadores SET dni = ?, nombre = ?, apellido1= ?, apellido2 = ?, calle = ?, numero = ?, piso = ?, mano = ?, tlf_empresa = ?, tlf_personal = ?, fecha_nac = ?, salario = ?, tipo = ? WHERE dni= ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ps.setString(2, nom);
            ps.setString(3, ape1);
            ps.setString(4, ape2);
            ps.setString(5, calle);
            ps.setString(6, num);
            ps.setString(7, piso);
            ps.setString(8, mano);
            ps.setString(9, emp);
            ps.setString(10, per);
           
            java.sql.Date fec = new java.sql.Date(fech.getTime().getTime());
            ps.setDate(11, fec);
            
            ps.setFloat(12, sal);
            ps.setString(13, tipo);
            
            ps.setString(14, dni);
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
    
    public static void insertar(String dni, String nom, String ape1, String ape2, String calle, String num, String piso, String mano, String emp, String per,Calendar fech, Float sal, String tipo) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            
            String plantilla;

            plantilla = "INSERT INTO Trabajadores VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ps.setString(2, nom);
            ps.setString(3, ape1);
            ps.setString(4, ape2);
            ps.setString(5, calle);
            ps.setString(6, num);
            ps.setString(7, piso);
            ps.setString(8, mano);
            ps.setString(9, emp);
            ps.setString(10, per);
            
            java.sql.Date fec = new java.sql.Date(fech.getTime().getTime());
            ps.setDate(11, fec);
            
            ps.setFloat(12, sal);
            ps.setString(13, tipo);
            ps.setInt(14, Controlador.Main.getC().getId_centro());
            

            ps.executeUpdate();
            
            
            cerrarConexion();
        
        
            
        }
        
    }
