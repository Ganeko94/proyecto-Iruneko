package Modelo;

/**
 *
 * @author 1gprog04
 */


public class Administracion extends Trabajador{
    

}
