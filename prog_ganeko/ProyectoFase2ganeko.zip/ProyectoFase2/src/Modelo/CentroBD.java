package Modelo;

import static Modelo.GenericoBD.abrirConexion;
import static Modelo.GenericoBD.cerrarConexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog04
 */

public class CentroBD extends GenericoBD{
    
    private static Centro c;
    
    public static ArrayList<Integer> buscarCentros() throws Exception{
        
            ArrayList<Integer> IDs = new ArrayList();
        
            abrirConexion();
            
            Statement sentencia = GenericoBD.getCon().createStatement();
            ResultSet resultado = sentencia.executeQuery("SELECT id_centro FROM Centros");
            while(resultado.next()){
                IDs.add(resultado.getInt(1));
            }
            cerrarConexion();
            return IDs;
                    
        }
        
        
    public static Centro buscarCentroID(int id) throws Exception{
        abrirConexion();
        
        String plantilla="SELECT * FROM Centros WHERE id_centro = ?";
        
        PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next() == false)
            {
                c = null;
        }
        else
        {
            c = new Centro();
            
            c.setId_centro(id);
            c.setNombre(rs.getString("nombre"));
            c.setTlf_fijo(rs.getString("tlf_fijo"));
            c.setCp(rs.getString("cp"));
            c.setProvincia(rs.getString("provincia"));
            c.setCiudad(rs.getString("ciudad"));
            c.setCalle(rs.getString("calle"));
            c.setNumero(rs.getString("numero"));
        }
        
        cerrarConexion();
        return c;
    }
    
    public static void borrar(int id)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Centros WHERE id_centro = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setInt(1, c.getId_centro());
             
            ps.executeUpdate();
            
            
            
            
            cerrarConexion();
            
        } 
    
        public static void insertar(int id, String nom, String fijo, int codp, String prov, String ciu, String cal, String num) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            
            String plantilla;

            plantilla = "INSERT INTO Centros VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setInt(1, id);
            ps.setString(2, nom);
            ps.setString(3, fijo);
            ps.setInt(4, codp);
            ps.setString(5, prov);
            ps.setString(6, ciu);
            ps.setString(7, cal);
            ps.setString(8, num);
            
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }
        
        public static void actualizar(int id, String nom, String fijo, int codp, String prov, String ciu, String cal, String num) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Centros SET id_centro = ?, nombre = ?, tlf_fijo = ?, cp = ?, provincia = ?, ciudad = ?, calle = ?, numero = ? WHERE id_centro = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setInt(1, id);
            ps.setString(2, nom);
            ps.setString(3, fijo);
            ps.setInt(4, codp);
            ps.setString(5, prov);
            ps.setString(6, ciu);
            ps.setString(7, cal);
            ps.setString(8, num);
            
            ps.setInt(9, id);
                       
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
    
    
}
