package Modelos;

import java.sql.*;
import javax.swing.JOptionPane;

public class GenericoBD {
    
    private static Connection conex;
    
    public static void abrirConex() {
        
        try {
            
            Class.forName("oracle.jdbc.OracleDriver");
        
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            String user = "daw11";
            String pass = "daw11";
            
            conex = DriverManager.getConnection (url,user,pass);
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en abrirConex!");
        }
        
    }
    
    public static void cerrarConex() {
        
        try {
            conex.close();
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en cerrarConex!");
        }
    
    }
    
    public static Connection getConex() {
        return conex;
    }
    
}
