package Modelos;

public class Administracion extends Trabajador {
    
}
