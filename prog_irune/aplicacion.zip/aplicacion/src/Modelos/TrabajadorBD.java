package Modelos;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TrabajadorBD extends GenericoBD {
    
    public static Trabajador t = new Trabajador();
    
    public static Trabajador buscarDni(String dni) {
        
        try {
            
            abrirConex();
            
            String plantilla = "SELECT * FROM Trabajadores WHERE dni = ?";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            sentencia.setString(1, dni);
            
            ResultSet resultado = sentencia.executeQuery();
            
            if (resultado.next() == false) {
                t = null;
            }
            else {
                
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlf_empresa"));
                t.setTlf_personal(resultado.getString("tlf_personal"));
                t.setFecha_nac(new java.util.Date(resultado.getDate("fecha_nac").getTime()));
                t.setSalario(resultado.getFloat("salario"));
                t.setTipo(resultado.getString("tipo"));
                
            }
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en buscarDni!");
        }
        
        return t;
        
    }
    
    public static void borrarTrabajador(String dni) {
        
        try {
            
            abrirConex();
            
            String plantilla = "DELETE FROM Trabajadores WHERE dni = ?";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            sentencia.setString(1, dni);
             
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El trabajador ha sido eliminado!");
            
            cerrarConex();
         
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en borrarTrabajador!");
        }
        
    }
    
    public static void modificarTrabajador(Trabajador t) {
        
        try {
            
            abrirConex();   
            
            String plantilla = "UPDATE Trabajadores SET dni = ?, nombre = ?, apellido1 = ?, apellido2 = ?, calle = ?, numero = ?, piso = ?, mano = ?, tlf_empresa = ?, tlf_personal = ?, fecha_nac = ?, salario = ?, tipo= ? WHERE dni = ?";
            PreparedStatement sentencia = getConex().prepareStatement(plantilla);
            
            sentencia.setString(1, t.getDni());
            sentencia.setString(2, t.getNombre());
            sentencia.setString(3, t.getApellido1());
            sentencia.setString(4, t.getApellido1());
            sentencia.setString(5, t.getCalle());
            sentencia.setString(6, t.getNumero());
            sentencia.setString(7, t.getPiso());
            sentencia.setString(8, t.getMano());
            sentencia.setString(9, t.getTlf_empresa());
            sentencia.setString(10, t.getTlf_personal());
            sentencia.setDate(11, new java.sql.Date(t.getFecha_nac().getTime()));
            sentencia.setFloat(12, t.getSalario());
            sentencia.setString(13, t.getTipo());
            
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El trabajador ha sido editado!");
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en modificarTrabajador!");
        }
        
    }
    
    public static void insertarTrabajador(Trabajador t) {
        
        try {
            
            abrirConex();
            
            String plantilla = "INSERT INTO Trabajadores VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            
            sentencia.setString(1, t.getDni());
            sentencia.setString(2, t.getNombre());
            sentencia.setString(3, t.getApellido1());
            sentencia.setString(4, t.getApellido1());
            sentencia.setString(5, t.getCalle());
            sentencia.setString(6, t.getNumero());
            sentencia.setString(7, t.getPiso());
            sentencia.setString(8, t.getMano());
            sentencia.setString(9, t.getTlf_empresa());
            sentencia.setString(10, t.getTlf_personal());
            sentencia.setDate(11, new java.sql.Date(t.getFecha_nac().getTime()));
            sentencia.setFloat(12, t.getSalario());
            sentencia.setString(13, t.getTipo());
            
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El trabajador ha sido añadido!");
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en insertarTrabajador!");
        }
        
    }
    
    public static ArrayList<Trabajador> TrabajadoresCentro(String id_centro) {
        
        try {
            
            ArrayList<Trabajador> listadoTrabajadores = new ArrayList();
            
            abrirConex();
            
            String plantilla = "SELECT * FROM Trabajadores WHERE id_centro = ?";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            sentencia.setString(1, id_centro);
            
            ResultSet resultado = sentencia.executeQuery();
            
            while(resultado.next() == true) {
                
                t.setDni(resultado.getString("dni"));
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlf_empresa"));
                t.setTlf_personal(resultado.getString("tlf_personal"));
                t.setFecha_nac(new java.util.Date(resultado.getDate("fecha_nac").getTime()));
                t.setSalario(resultado.getFloat("salario"));
                t.setTipo(resultado.getString("tipo"));
                
                listadoTrabajadores.add(t);
                
            }
            
            cerrarConex();
            
            return listadoTrabajadores;
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en buscarCentro!");
        }
        
        return null;
    
    }
    
}
