package Modelos;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CentroBD extends GenericoBD {
    
    public static Centro buscarCentro(Centro c) {
        
        try {
            
            abrirConex();
            
            String plantilla = "SELECT * FROM Centros WHERE id_centro = ?";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            sentencia.setString(1, c.getId_centro());
            
            ResultSet resultado = sentencia.executeQuery();
            
            if (resultado.next() == false) {
                c = null;
            }
            else {
                
                c.setId_centro(resultado.getString("id_cento"));
                c.setNombre(resultado.getString("nombe"));
                c.setTlf_fijo(resultado.getString("tlf_fijo"));
                c.setCp(resultado.getString("cp"));
                c.setProvincia(resultado.getString("provincia"));
                c.setCiudad(resultado.getString("ciudad"));
                c.setCalle(resultado.getString("calle"));
                c.setNumero(resultado.getString("numero"));
                
            }
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en buscarCentro!");
        }
        
        return c;
        
    }
    
    public static void borrarCentro(String id_centro) {
        
        try {
            
            abrirConex();
            
            String plantilla = "DELETE FROM Centros WHERE id_centro = ?";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            sentencia.setString(1, id_centro);
             
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El centro ha sido eliminado!");
            
            cerrarConex();
         
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en borrarCentro!");
        }
        
    }
    
    public static void modificarCentro(Centro c) {
        
        try {
            
            abrirConex();   
            
            String plantilla = "UPDATE Centros SET id_centro = ?, nombre = ?, tlf_fijo = ?, cp = ?, provincia = ?, ciudad = ?, calle = ?, numero = ? WHERE id_centro = ?";
            PreparedStatement sentencia = getConex().prepareStatement(plantilla);
            
            sentencia.setString(1, c.getId_centro());
            sentencia.setString(2, c.getNombre());
            sentencia.setString(3, c.getTlf_fijo());
            sentencia.setString(4, c.getCp());
            sentencia.setString(5, c.getProvincia());
            sentencia.setString(6, c.getCiudad());
            sentencia.setString(7, c.getCalle());
            sentencia.setString(8, c.getNumero());
            
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El centro ha sido editado!");
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en modificarCentro!");
        }
        
    }
    
    public static void insertarCentro(Centro c) {
        
        try {
            
            abrirConex();
            
            String plantilla = "INSERT INTO Centros VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            
            sentencia.setString(1, c.getId_centro());
            sentencia.setString(2, c.getNombre());
            sentencia.setString(3, c.getTlf_fijo());
            sentencia.setString(4, c.getCp());
            sentencia.setString(5, c.getProvincia());
            sentencia.setString(6, c.getCiudad());
            sentencia.setString(7, c.getCalle());
            sentencia.setString(8, c.getNumero());
            
            sentencia.executeUpdate();
            JOptionPane.showMessageDialog(null, "El centro ha sido añadido!");
            
            cerrarConex();
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en insertarCentro!");
        }
        
    }
    
    public static ArrayList<String> nombreCentros() {
        
        try {
            
            ArrayList<String> listadoCentro = new ArrayList();
            
            abrirConex();
            
            String plantilla = "SELECT * FROM Centros";
            PreparedStatement sentencia = GenericoBD.getConex().prepareStatement(plantilla);
            
            ResultSet resultado = sentencia.executeQuery();
            
            while(resultado.next()) {
                
                listadoCentro.add(resultado.getString("nombre"));
                
            }
            
            cerrarConex();
            
            return listadoCentro;
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en nombreCentros!" + e.getMessage());
            return null;
        }
        
    }
    
}
