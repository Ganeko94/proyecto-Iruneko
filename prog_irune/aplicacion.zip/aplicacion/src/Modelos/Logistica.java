package Modelos;

public class Logistica extends Trabajador {
    
}
