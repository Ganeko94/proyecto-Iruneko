package Excepciones;

public class DniNoValido extends Exception {
    
}
