package Controlador;

import Excepciones.*;
import Modelos.*;
import Vistas.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.*;
import javax.swing.JOptionPane;

public class Control {
    
    private static Principal dp;
    private static Fondo vf;
    private static Perfil vp;
    private static ArrayList<String> centros;
    
    private static Centro c;
    private static Trabajador t;
    
    public static void main(String[] args) {
        verFondo();
        verPrincipal();
        mostrarCentros();
    }
    
    public static void verFondo() {
        vf = new Fondo();
        vf.setVisible(true);
    }
    
    public static void verPrincipal() {
        dp = new Principal(vf, true);
        dp.setVisible(true);
    }
    
    public static ArrayList<String> mostrarCentros(){
        centros = new ArrayList();
        centros = CentroBD.nombreCentros();
        return centros;
    }
    
    public static void entrar(String dni) {
        
        try {
            
            Pattern dniPattern = Pattern.compile("([0-9]{8})([A-Z,a-z])");
            Matcher m = dniPattern.matcher(dni);

            if (m.matches()) {
                
                try {
                    
                    t = TrabajadorBD.buscarDni(dni);
                    
                    if (t == null) {
                        JOptionPane.showMessageDialog(null, "El trabajador NO existe!");
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "El trabajador SI existe!");
                    }
                    
                    verPerfil(dni);
                    
                }
                catch(Exception e) {
                    JOptionPane.showMessageDialog(null, "ERROR en entrar!");
                }
                
            }
            else {
                throw new DniNoValido();
            }
            
        }
        
        catch(DniNoValido e) {
            JOptionPane.showMessageDialog(null, "ERROR! \nEl dni introducido no es valido, prueba otra vez.");
        }
        
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR en entrar1!");
        }
        
    }
    
    public static void verPerfil(String dni) {
        dp.dispose();
        vp = new Perfil();
        vp.setVisible(true);
        
        guardarDni(dni);
    }
    
    public static void guardarDni(String dni) {
        Perfil.tfDni2.setText(dni);
        Perfil.tfDni2.setEditable(false);
    }
    
    public static void salir() {
        System.exit(0);
    }
    
    public static void atras() {
        vp.dispose();
        verPrincipal();
    }
    
    public static void guardar() {
        vp.dispose();
        verPrincipal();
    }
    
    public static String getDni() {
        return t.getDni();
    }
    public static void setDni(String dni) {
        t.setDni(dni);
    }

    public static String getNombre() {
        return t.getNombre();
    }
    public static void setNombre(String nombre) {
        t.setNombre(nombre);
    }

    public static String getApellido1() {
        return t.getApellido1();
    }
    public static void setApellido1(String apellido1) {
        t.setApellido1(apellido1);
    }

    public static String getApellido2() {
        return t.getApellido2();
    }
    public static void setApellido2(String apellido2) {
        t.setApellido2(apellido2);
    }

    public static String getCalle() {
        return t.getCalle();
    }
    public static void setCalle(String calle) {
        t.setCalle(calle);
    }

    public static String getNumero() {
        return t.getNumero();
    }
    public static void setNumero(String numero) {
        t.setNumero(numero);
    }

    public static String getPiso() {
        return t.getPiso();
    }
    public static void setPiso(String piso) {
        t.setPiso(piso);
    }

    public static String getMano() {
        return t.getMano();
    }
    public static void setMano(String mano) {
        t.setMano(mano);
    }

    public static String getTlf_empresa() {
        return t.getTlf_empresa();
    }
    public static void setTlf_empresa(String tlf_empresa) {
        t.setTlf_empresa(tlf_empresa);
    }

    public static String getTlf_personal() {
        return t.getTlf_personal();
    }
    public static void setTlf_personal(String tlf_personal) {
        t.setTlf_personal(tlf_personal);
    }

    public static Date getFecha_nac() {
        return t.getFecha_nac();
    }
    public static void setFecha_nac(Date fecha_nac) {
        t.setFecha_nac(fecha_nac);
    }

    public static float getSalario() {
        return t.getSalario();
    }
    public static void setSalario(float salario) {
        t.setSalario(salario);
    }

    public static String getTipo() {
        return t.getTipo();
    }
    public static void setTipo(String tipo) {
        t.setTipo(tipo);
    }
    
    public static String getIdCentro() {
        return c.getId_centro();
    }
    public static void setIdCentro(String idCentro) {
        c.setId_centro(idCentro);
    }
    
}
